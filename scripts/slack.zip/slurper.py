import json
import os
import time

import requests
import urllib

OUTPUT_DIR = "CHANGE_ME"
TOKEN = "CHANGE_ME"
BASE_URL = "https://slack.com/api/channels.history"
PAGE_SIZE = 1000
MAX_MSGS = PAGE_SIZE * 200
CHANNELS = {
    'CB9GFD1C1': '#db-slave-err-premium',
    'C9B422JTU': '#db-slave-err-billing',
    'C9DPRP4M6': '#db-slave-err-chat',
    'C9ECX99RA': '#db-slave-err-crm-inbx',
    'C9B7HHNRK': '#db-slave-err-ecom',
    'CC2KMJV5M': '#db-slave-err-htm-auto',
    'C8ZTMHFKK': '#db-slave-err-htm-edit',
    'C9FF38YKZ': '#db-slave-err-payments',
    'C4QH4GC1W': '#db-slave-errors'
}


def main():
    for channel, channel_name in CHANNELS.items():
        print("[+] Downloading data for channel {} AKA {}.".format(channel, channel_name))
        page = get_page(channel)
        msgs = page
        for i in range(0, MAX_MSGS // PAGE_SIZE - 1):
            time.sleep(1)
            timestamp = page[-1]['ts']
            page = get_page(channel, timestamp)
            msgs += page

            if len(page) < PAGE_SIZE:
                break

        print("[+] Writing {} msgs for channel {}.".format(len(msgs), channel_name))
        with open(os.path.join(OUTPUT_DIR, '{}.json'.format(channel_name)), "w+") as fout:
            fout.write(json.dumps(msgs))


def get_page(channel, timestamp=None):
    if timestamp:
        params = {"token": TOKEN, "count": PAGE_SIZE, "channel": channel, "latest": timestamp, "inclusive": False}
    else:
        params = {"token": TOKEN, "count": PAGE_SIZE, "channel": channel}
    url = '{}?{}'.format(BASE_URL, urllib.urlencode(params))
    response = requests.get(url)
    response.raise_for_status()
    return response.json()['messages']


if __name__ == '__main__':
    main()
